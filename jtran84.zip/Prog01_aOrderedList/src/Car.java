

/**
* This is the car class which holds the constructor for our objects and instances that we create. It implements
* a comparable interface that allows us to use the "compareTo" method which compares two objects to each other.
*
* CSC 1351 Programming Project No <01>
*
* Section <2>
*
* @author <Justin Tran>
* @since <3/17/2024>
*
*/

public class Car implements Comparable<Car>{

	//Private declared variables
	private String make;
	private int year;
	private int price;
	
	//Car Constructor
	public Car(String Make, int Year, int Price) {
		this.make = Make;
		this.year = Year;
		this.price = Price;
	}
	
	/**
	* Returns the make of the car
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public String getMake() {
		return make;
	}
	
	/**
	* Returns the year of the car
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	public int getYear() {
		return year;
	}
	
	/**
	* Returns the price of the car
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public int getPrice() {
		return price;
	}
	
	/**
	* This is the compareTo method which compares two car objects that are compared by their make. However, if their
	* makes are the same then it compares them by their year in order to compare/sort them.
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	@Override
	public int compareTo (Car other) {
		if (this.make.compareTo(other.make) == 0) {
			return Integer.compare(this.year, other.year);
		}
		else {
		return this.make.compareTo(other.getMake());
		}
	}
	
	/**
	* Method that just returns the make, year, and price
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/

	public String toString() {
		return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
	}
}
