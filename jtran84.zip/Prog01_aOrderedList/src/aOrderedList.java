import java.util.Arrays;
import java.util.Collections;

/**
* This is the "aOrderedList" class that allows us to iterate and position the elements of the ordered list. It contains
* functions that allow us to add and remove elements from the list while still keeping it in order.
*
* CSC 1351 Programming Project No <01>
7
* Section <2>
*
* @author <Justin Tran>
* @since <3/17/2024>
*
*/

public class aOrderedList {

	final int SIZEINCREMENTS = 20;
	
	private Comparable[] oList;
	private int listSize;
	private int numObjects;
	private int curr;
	
	public aOrderedList(){
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		oList = new Comparable[SIZEINCREMENTS];
	}	
	
	/**
	* Method that just returns the current number of objects
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public int size() {
		return numObjects;
	}
	
	/**
	* Method that returns the index of a car in the array list
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public Comparable get(int index) {
		return oList[index];
	}
	
	/**
	* Method that checks if the list is empty
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public boolean isEmpty() {
		if (oList.length == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	* Method that removes a car or object within a given index. If the index is out of bounds then it throws
	* an IndexOutOfBoundsException and tells the user that the index is out of bounds. Also makes the list "shrinkable"
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public void remove(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("The index: <" + index + "> is out of bounds.");
		}
		for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        numObjects--;
	}

	/**
	* Method that adds a car to the list. If the list is equal to the number of objects inside of it, in other words, full,
	* then it extends the list until it can fit the amount of objects being put into it.
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	void addCar(Comparable newCar){
		if(listSize == numObjects) {
			listSize++;
		}
		int i;
		oList = Arrays.copyOf(oList,listSize);
		for(i = numObjects - 1; i >= 0 && oList[i].compareTo(newCar) > 0; i--) {
			oList[i + 1] = oList[i];
		}
		oList[i + 1] = newCar;
		numObjects++;
	}
	
	/**
	* Resets the index of a current element back to 0
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public void reset(){
		curr = 0;
	}
	
	/**
	* Returns the next element in the list
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public Comparable next() {
		if(curr >= numObjects) {
			throw new IndexOutOfBoundsException("There are no elements in the list.");
		}
		return oList[curr++];
	}
	
	/**
	* Method that just returns the true if it has more elements to iterate through
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public boolean hasNext() {
		if(curr > numObjects) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	* Method that removes the last element returned by the next() method.
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public void removeCurr(){
		for (int i = curr; i < numObjects-1; i++){
			oList[i] = oList[i+1];
	        }
		oList[curr] = null;
	    numObjects--;
	}
	
	
	
	/**
	* Formats the input of the values returned by the Car class's toString method
	*
	* CSC 1351 Programming Project No <01>
	*
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
	
	public String toString() {
		String valOrganized = "[";
        for (int i = 0; i < numObjects; i++) {
            valOrganized += oList[i].toString();
            if (i < numObjects - 1) {
                valOrganized += ", ";
            }
        }
        valOrganized += "]";
        return valOrganized;
	}
}
