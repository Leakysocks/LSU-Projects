import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.PrintWriter;
import java.io.File;


/**
* This is the Ordered List class that has the get input and output methods inside of it that gets called so the user
* can input the name of each one. Furthermore, its main class handles deleting and adding cars to the Output file at 
* a given index when reading the first letter A or D in it's index: 0. It's also where it prints out the output from
* the input in a special format.
*
* CSC 1351 Programming Project No <01>
7
* Section <2>
*
* @author <Justin Tran>
* @since <3/17/2024>
*
*/

public class Prog01_aOrderedList {

	public static void main(String[] args) {
				
        try {  	
        	//Calls getInputFile to get the input file
            Scanner myScan = getInputFile("Enter input filename: ");
            aOrderedList myOrderedList = new aOrderedList();
            
            while(myScan.hasNextLine()){
            	String input = myScan.nextLine();
            	String[] parsed = input.split(",");
            	if(parsed.length == 4 && parsed[0].equals("A")) {
            		String carMake = parsed[1];
            		int carYear = Integer.parseInt(parsed[2]);
            		int carPrice = Integer.parseInt(parsed[3]);
            		myOrderedList.addCar(new Car(carMake, carYear, carPrice));
            		
            	} else if (parsed[0].equals("D")) {
            		String inputMake = parsed[1];
                    int inputYear = Integer.parseInt(parsed[2]);
                    for(int i = 0; i < myOrderedList.size(); i++)
                    if (inputMake.equals(((Car)myOrderedList.get(i)).getMake()) && inputYear == (((Car)myOrderedList.get(i)).getYear())) {
                    	myOrderedList.remove(i);
                    	}
                    }
            	}
            myScan.close();
            
            //Calls getOutputFile to get the output file
            PrintWriter outputFile = getOutputFile("Enter output filename: ");
            String orderedListString = ("Number of cars:\t\t" + myOrderedList.size() + "\n");
            int carIndex = 0;
            while(carIndex < myOrderedList.size()) {
            	orderedListString += String.format("\n\nMake:\t%s\nYear:\t%d\nPrice:\t$%,d", ((Car)myOrderedList.get(carIndex)).getMake(),
            	((Car)myOrderedList.get(carIndex)).getYear(), ((Car)myOrderedList.get(carIndex)).getPrice());
            	carIndex++;
            }
            outputFile.print(orderedListString);
            outputFile.close();
        }
        catch (FileNotFoundException e) {
            System.out.printf(e.getMessage());
        }
    }

	/**
	* The getInputFile method is a method that is designed to take in the user prompt (the question that will be 
	* asked to the user) and retrieve the name of the input file through user input. It detects whether or not the 
	* file exists and if it does, it returns a scanner object; that being, the input file, but if it doesn't exist
	* then the program will notify the user that it doesn't exist, throws a new FileNotFoundException and prompts
	* the user if they would like to continue or not. If they input "Y" it prompts the user again, but if they input
	* "N" then it will stop the program.
	*
	* CSC 1351 Programming Project No <01>
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/

    public static Scanner getInputFile(String UserPrompt) throws FileNotFoundException {
    	
        Scanner inScan = null;
        boolean validFilename = false;
        
        while (!validFilename) {
        	System.out.println(UserPrompt);
            Scanner inputScan = new Scanner(System.in);
            String userInput = inputScan.nextLine();

            File inputFile = new File(userInput);
            if (!inputFile.exists()) {
                System.out.printf("File specified <%s> does not exist.\nWould you like to continue? <Y/N>\n", userInput);
                String choice = inputScan.nextLine();
                if (!choice.equalsIgnoreCase("Y")) {
                	throw new FileNotFoundException("User cancelled the program.");
                } 
                else {
                    continue;
                }
            }
            inScan = new Scanner(inputFile);
            validFilename = true;
        }
        return inScan;
    }
    
    /**
	* The getOutputFile method is a method that is designed to take in the user prompt (the question that will be 
	* asked to the user) and retrieve the name of the output file through user input. It detects whether or not the 
	* file exists and if it does, it returns a writer object; that being, the output file, but if it doesn't exist
	* then the program will notify the user that it doesn't exist, throws a new FileNotFoundException and prompts
	* the user if they would like to continue or not. If they input "Y" it prompts the user again, but if they input
	* "N" then it will stop the program.
	*
	* CSC 1351 Programming Project No <01>
	* Section <2>
	*
	* @author <Justin Tran>
	* @since <3/17/2024>
	*
	*/
    
    public static PrintWriter getOutputFile(String UserPrompt) throws FileNotFoundException {
    	
    	Scanner inScan = new Scanner(System.in);
    	PrintWriter Writer = null;
    	boolean isValid = false;
    	
    	while(!isValid) {
    		System.out.println(UserPrompt);
    		String userInput = inScan.nextLine();
    		File outputFile = new File(userInput);
    		if(!outputFile.exists()) {
    			System.out.printf("File specified <%s> does not exist.\nWould you like to continue? <Y/N>\n", userInput);
    			String choice = inScan.nextLine();
    			if(!choice.equalsIgnoreCase("Y")) {
    				throw new FileNotFoundException("User cancelled the program.");
    			}
    			}else {
    			Writer = new PrintWriter(outputFile);
    			isValid = true;
    		}
    	}
    	return Writer;
    }
}